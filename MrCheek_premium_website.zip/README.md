# MrCheek Premium

Flask + Tesseract OCR Android screenshot analyzer.

## Run on Kali/Debian
sudo apt update
sudo apt install -y python3 python3-pip tesseract-ocr
pip install -r requirements.txt
python3 app.py

Open http://127.0.0.1:5000

For public deployment use a Python-capable host/VPS and HTTPS. This project intentionally does not claim guaranteed rootability from a screenshot.
